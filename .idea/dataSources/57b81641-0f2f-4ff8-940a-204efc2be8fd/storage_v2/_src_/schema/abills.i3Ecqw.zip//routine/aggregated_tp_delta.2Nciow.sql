CREATE FUNCTION aggregated_tp_delta(tp_id INT, date DATE)
  RETURNS INT
  BEGIN
  DECLARE aggregated_delta INTEGER;
  SELECT 
    SUM(a.`delta`)
  FROM `tp_move_deltas` a
  WHERE 
    a.`f` = tp_id AND  
    a.`date` > date 
  INTO aggregated_delta;
  RETURN aggregated_delta;
END;

