CREATE FUNCTION calc_loyality_date(loyality_uid INT)
  RETURNS DATETIME
  BEGIN
  DECLARE loyality_date DATETIME;
  SELECT 
    max(i.st)
  FROM
  (
    SELECT 
      count(f.tid) as cnt,
      time_intervals.start as st
    FROM
  	  time_intervals
    LEFT OUTER JOIN 
    (
      SELECT 
  	    fees.`time_interval_id` as tid
  	  FROM 
        fees
 	  WHERE
	    fees.uid=loyality_uid
        and fees.`last_deposit` >= fees.`sum`
    ) f 
    ON (time_intervals.id = f.tid)
    WHERE 
      time_intervals.`start`<CURRENT_DATE
    GROUP BY
      time_intervals.id
  ) i
  WHERE
    i.cnt=0 
  INTO loyality_date;

  RETURN loyality_date;
   
END;

