CREATE PROCEDURE calc_phone2()
  BEGIN
UPDATE
  users_pi
  SET phone2=
  IF(users_pi.phone regexp '^80[0-9]{9}$', 
  	CONCAT('3', users_pi.phone), 
    IF(users_pi.phone regexp '^[0-9]{9}$',
      CONCAT('380', users_pi.phone), 
      IF(users_pi.phone regexp '^[0-9]{5}$',
        CONCAT('3804744', users_pi.phone), null
      )
    )
  );

END;

