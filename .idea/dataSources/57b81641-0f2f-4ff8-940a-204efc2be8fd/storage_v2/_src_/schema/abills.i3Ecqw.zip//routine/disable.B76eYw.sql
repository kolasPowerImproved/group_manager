CREATE PROCEDURE disable()
  BEGIN
  DECLARE done BOOLEAN DEFAULT FALSE;
  DECLARE _id BIGINT UNSIGNED;
  DECLARE cur CURSOR FOR SELECT a.uid FROM (
SELECT 
  users.uid,
  users.id,
  MAX(fees.last_deposit) AS ld,
  fees.`date`,
  fees.`sum`
FROM
  fees
  INNER JOIN companies ON (fees.bill_id = companies.bill_id)
  INNER JOIN users ON (companies.id = users.company_id)
  INNER JOIN dv_main ON (users.uid = dv_main.uid)
WHERE
  fees.`date` >= '2014-08-01' AND 
  fees.`sum` > 24 AND
  NOT `dv_main`.`tp_id` IN (401, 403, 11)
GROUP BY
  users.id,
  fees.`date`
HAVING
  ld <= -24
) a;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done := TRUE;

  OPEN cur;

  testLoop: LOOP
    FETCH cur INTO _id;
    IF done THEN
      LEAVE testLoop;
    END IF;
    CALL disable_uid(_id);
  END LOOP testLoop;

  CLOSE cur;
END;

