CREATE PROCEDURE disable_uid(IN `_uid` INT)
  BEGIN
	UPDATE dv_main SET tp_id=401 WHERE uid = _uid;
    INSERT INTO `admin_actions` VALUES ('AUTO DISABLE ->401', NOW(), INET_ATON('192.168.33.152'), _uid, 42, null, 'Dv', 0, 0);
END;

