CREATE PROCEDURE make_payment_old(IN sum         FLOAT, IN bill_id INT, IN user_id INT, IN admin_id INT,
                                  IN description VARCHAR(100), IN ipaddress VARCHAR(16), IN methodid INT, IN ext_id INT)
  BEGIN

DECLARE last_deposit FLOAT;
DECLARE tmp_credit FLOAT;
DECLARE tmp_uid INTEGER(11);
DECLARE var_company_id INTEGER(11);
DECLARE tmp_company_id INTEGER(11);
DECLARE done INT DEFAULT FALSE;

DECLARE cur1 CURSOR FOR SELECT 
  id,
  credit
FROM 
  companies
WHERE
  companies.id = var_company_id
  AND companies.credit > 0
;

DECLARE cur2 CURSOR FOR SELECT 
  uid,
  credit
FROM 
  users
WHERE
  users.company_id = var_company_id 
  AND users.credit > 0
;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

-- IF bill_id<1 THEN
  SELECT 
    companies.bill_id
  FROM
    users
    INNER JOIN companies ON (users.company_id = companies.id)
  WHERE 
    users.uid = user_id
  INTO bill_id;
-- END IF;
 
SELECT deposit FROM bills WHERE `id`=bill_id INTO last_deposit;

SELECT company_id FROM users WHERE `uid`=user_id INTO var_company_id;

UPDATE bills SET deposit = deposit + sum WHERE id = bill_id;

-- SELECT MAX(id)+1 FROM payments INTO ext_id;

INSERT INTO payments SET 
  date = now(),
  sum = sum,
  dsc = description,
  ip = inet_aton(ipaddress),
  last_deposit = last_deposit,
  uid = user_id,
  aid = admin_id,
  bill_id = bill_id,
  method = methodid,
  ext_id = ext_id
;

OPEN cur1;

read_loop: LOOP
  FETCH cur1 INTO tmp_company_id, tmp_credit;
  IF done THEN
    LEAVE read_loop;
  END IF;
  
  UPDATE companies SET credit = 0 WHERE id = var_company_id;
  
  INSERT INTO admin_actions SET
    actions = CONCAT("COMAPNY CREDIT CHANGED ",tmp_credit,"->0 DUE PAYMENT"),
    ip = inet_aton(ipaddress),
    uid = user_id,
    company_id = var_company_id,
    aid = admin_id,
    datetime = now(),
    module = "ABM"
  ;
      
END LOOP;
  
CLOSE cur1;

SET done = FALSE;

OPEN cur2;

read_loop_2: LOOP
  FETCH cur2 INTO tmp_uid, tmp_credit;
  IF done THEN
    LEAVE read_loop_2;
  END IF;

  UPDATE users SET credit = 0 where uid = tmp_uid;
  
  INSERT INTO admin_actions SET
    actions = CONCAT("USER CREDIT CHANGED ",tmp_credit,"->0 DUE PAYMENT"),
    ip = inet_aton(ipaddress),
    uid = tmp_uid,
    company_id = var_company_id,
    aid = admin_id,
    datetime = now(),
    module = "ABM"
  ;
  
END LOOP;

CLOSE cur2;

END;

