CREATE PROCEDURE tp_stats()
  BEGIN
SELECT 
  dv_main.tp_id,
  tarif_plans.name,
  count(users.uid) AS cnt
FROM
  users
  INNER JOIN dv_main ON (users.uid = dv_main.uid)
  INNER JOIN tarif_plans ON (dv_main.tp_id = tarif_plans.id)
  INNER JOIN (
	 SELECT `companies`.id FROM bills
     INNER JOIN companies ON (bills.company_id = companies.id)
     INNER JOIN payments ON (`payments`.`bill_id` = bills.`id`)
  WHERE
     payments.`date`>'2011-09-01' OR
     bills.`deposit` >= 0
  GROUP BY
     payments.uid
  )b ON users.company_id=b.id
WHERE
  NOT users.disable
GROUP BY
  dv_main.tp_id;
END;

