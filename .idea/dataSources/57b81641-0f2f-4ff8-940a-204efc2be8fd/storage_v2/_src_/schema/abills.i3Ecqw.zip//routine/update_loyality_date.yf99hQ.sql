CREATE PROCEDURE update_loyality_date()
  BEGIN

UPDATE
  fees,
  `time_intervals`
SET
  fees.`time_interval_id`=`time_intervals`.id
WHERE
  fees.`date`>=`time_intervals`.`start` AND
  fees.`date`<=`time_intervals`.end 

;
UPDATE 
  users_pi
SET
  `users_pi`.`_loyality_date`=calc_loyality_date(users_pi.`uid`)
;
 
UPDATE
  users_pi
SET
  `users_pi`.`_loyality_score` = PERIOD_DIFF(EXTRACT(YEAR_MONTH FROM NOW()), EXTRACT(YEAR_MONTH FROM `users_pi`.`_loyality_date`))
;

END;

